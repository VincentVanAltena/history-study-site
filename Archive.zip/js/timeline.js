fetch("data/timeline.json")
  .then(r => r.json())
  .then(data => renderTimeline(data.timeline));

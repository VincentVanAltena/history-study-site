function initQuiz(questions) {
  window.quizQuestions = questions;
  window.quizStats = {};
  
  questions.forEach(q => {
    window.quizStats[q.id] = { correct: 0, total: 0 };
  });

  if (typeof nextQuestion === 'function') {
    nextQuestion();
  }
}

fetch("../data/facts.json")
  .then(r => r.json())
  .then(data => initQuiz(data));

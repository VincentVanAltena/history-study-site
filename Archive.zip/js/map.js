window.map = L.map('map').setView([52, 5], 4);
window.mapLayers = {};

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(window.map);

function loadMapLayers(layers) {
  layers.forEach(layer => {
    if (layer.type === "polygon") {
      const poly = L.polygon(layer.coords).addTo(window.map);
      window.mapLayers[layer.name] = poly;
    } else if (layer.type === "point") {
      const marker = L.marker(layer.coords).addTo(window.map);
      window.mapLayers[layer.name] = marker;
    } else if (layer.type === "polyline") {
      const line = L.polyline(layer.coords).addTo(window.map);
      window.mapLayers[layer.name] = line;
    }
  });
}

fetch("../data/map_layers.json")
  .then(r => r.json())
  .then(data => loadMapLayers(data.mapLayers));

window.focusMap = function(layerName, coords) {
  if (!window.map) return;

  if (coords) {
    window.map.setView(coords, 6);
  }

  if (layerName && window.mapLayers[layerName]) {
    window.mapLayers[layerName].openPopup();
  }
};
